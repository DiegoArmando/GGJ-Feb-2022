#include <gb/gb.h>

// System fields
UBYTE _is_CGB, _is_SGB;
