#ifndef _SYSTEM_H_INCLUDE
#define _SYSTEM_H_INCLUDE

#include <gb/gb.h>

// System fields
extern UBYTE _is_CGB;
extern UBYTE _is_SGB;

#endif