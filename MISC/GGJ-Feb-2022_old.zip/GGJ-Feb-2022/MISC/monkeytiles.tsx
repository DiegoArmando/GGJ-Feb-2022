<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="monkeytiles" tilewidth="8" tileheight="8" tilecount="360" columns="20">
 <image source="tiles.png" width="160" height="144"/>
</tileset>
